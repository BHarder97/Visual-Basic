﻿Module Module1
    'Creating an array for the images
    Public Pictures() = {My.Resources.Grass, My.Resources.Fire, My.Resources.Water, My.Resources.Lightning, My.Resources.Lugia, My.Resources.Moltres, My.Resources.Zapdos, My.Resources.Articuno,
                     My.Resources.Entei, My.Resources.Suicune, My.Resources.Raikou, My.Resources.Charmander, My.Resources.Squirtle, My.Resources.Bulbasaur, My.Resources.Groudon,
                      My.Resources.Kyogre, My.Resources.Rayquaza, My.Resources.Regirock, My.Resources.Regice, My.Resources.Registeel,
                         My.Resources.Grass, My.Resources.Fire, My.Resources.Water, My.Resources.Lightning, My.Resources.Lugia, My.Resources.Moltres, My.Resources.Zapdos, My.Resources.Articuno,
                     My.Resources.Entei, My.Resources.Suicune, My.Resources.Raikou, My.Resources.Charmander, My.Resources.Squirtle, My.Resources.Bulbasaur, My.Resources.Groudon,
                      My.Resources.Kyogre, My.Resources.Rayquaza, My.Resources.Regirock, My.Resources.Regice, My.Resources.Registeel}

    'Creating an array for the image tags
    Public picTags() = {"Grass", "Fire", "Water", "Lightning", "Lugia", "Moltres", "Zapdos", "Articuno", "Entei", "Suicune", "Raikou",
                            "Charmander", "Squirtle", "Bulbasaur", "Groudon", "Kyogre", "Rayquaza", "Regirock", "Regice", "Registeel",
                        "Grass", "Fire", "Water", "Lightning", "Lugia", "Moltres", "Zapdos", "Articuno", "Entei", "Suicune", "Raikou",
                            "Charmander", "Squirtle", "Bulbasaur", "Groudon", "Kyogre", "Rayquaza", "Regirock", "Regice", "Registeel"}

    'Creating an array for linking tags to pictureboxes
    Public PicBoxes = {MainForm.PictureBox1, MainForm.PictureBox2, MainForm.PictureBox3, MainForm.PictureBox4, MainForm.PictureBox5, MainForm.PictureBox6, MainForm.PictureBox7, MainForm.PictureBox8, MainForm.PictureBox9, MainForm.PictureBox10,
                MainForm.PictureBox11, MainForm.PictureBox12, MainForm.PictureBox13, MainForm.PictureBox14, MainForm.PictureBox15, MainForm.PictureBox16, MainForm.PictureBox17, MainForm.PictureBox18, MainForm.PictureBox19, MainForm.PictureBox20,
                MainForm.PictureBox21, MainForm.PictureBox22, MainForm.PictureBox23, MainForm.PictureBox24, MainForm.PictureBox25, MainForm.PictureBox26, MainForm.PictureBox27, MainForm.PictureBox28, MainForm.PictureBox29, MainForm.PictureBox30,
                MainForm.PictureBox31, MainForm.PictureBox32, MainForm.PictureBox33, MainForm.PictureBox34, MainForm.PictureBox35, MainForm.PictureBox36, MainForm.PictureBox37, MainForm.PictureBox38, MainForm.PictureBox39, MainForm.PictureBox40}

End Module
